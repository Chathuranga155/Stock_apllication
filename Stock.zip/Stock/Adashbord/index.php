<html>
	<head>
		<meta http-equiv="refresh" content="0;url=./html/index.php" />
	</head>
</html>