<html>
	<head>
		<meta http-equiv="refresh" content="0;url=./public/index.html" />
	</head>

    
</html>